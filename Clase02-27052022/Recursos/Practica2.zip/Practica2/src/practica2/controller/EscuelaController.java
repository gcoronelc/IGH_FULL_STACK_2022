/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica2.controller;

import service.EscuelaService;

/**
 *
 * @author Jeanfranco
 */
public class EscuelaController {
    private EscuelaService escuelaService;
    
    public EscuelaController() {
		escuelaService = new EscuelaService();
	}
    public String comparar (int puntaje ){
	return escuelaService.comparar(puntaje);
    }
    
}
