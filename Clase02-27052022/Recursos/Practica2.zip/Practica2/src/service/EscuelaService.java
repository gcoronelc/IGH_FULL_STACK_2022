/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package service;

/**
 *
 * @author Jeanfranco
 */
public class EscuelaService {
    public String comparar (int puntaje ){
        String escuela="No alcanzó puntaje";
	escuela = (puntaje >= 50 && puntaje < 60) ? "Ingresó a Mecánica" : escuela;
	escuela = (puntaje >= 60 && puntaje < 70) ? "Ingresó a Industrial" : escuela;
	escuela = (puntaje >= 70 && puntaje < 80) ? "Ingresó a Electrónica" : escuela;
	escuela = (puntaje >= 80) ? "Ingresó a Sistemas" : escuela;
	return escuela;
    }
}
