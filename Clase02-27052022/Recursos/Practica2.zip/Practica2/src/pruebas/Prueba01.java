/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pruebas;

import service.EscuelaService;

/**
 *
 * @author Jeanfranco
 */
public class Prueba01 {

    public static void main(String[] args) {
        // Variables
        int puntaje;
        String escuela;
        // Datos
        puntaje = 60;
        // Proceso
        EscuelaService escuelaService = new EscuelaService();
        escuela = escuelaService.comparar(puntaje);
        // Reporte
        System.out.println("Usted " + escuela);
    }

}
