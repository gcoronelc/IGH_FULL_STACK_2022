/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.igh.proyecto01.controller;

import com.igh.proyecto01.service.ProyectoService;

/**
 *
 * @author DELL
 */
public class ProyectoController {
    private ProyectoService proyectoService;

    public ProyectoController() {
        this.proyectoService=new ProyectoService();
    }
    public String estado(int costo, int venta){
        return this.proyectoService.estado(costo, venta);
    }
    
}
