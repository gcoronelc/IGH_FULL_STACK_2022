/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.igh.proyecto01.pruebas;

import com.igh.proyecto01.service.ProyectoService;

/**
 *
 * @author DELL
 */
public class Prueba01 {
    public static void main(String args[]){
    //Variables
    int costo,venta;
    String resultado;
    //Datos
    costo=10;
    venta=15;
    //Proceso
    ProyectoService proyectoService= new ProyectoService();
    resultado=proyectoService.estado(costo,venta);
    //Reporte
        System.out.println("Resultado: "+resultado);
    }
}
