/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.igh.proyecto01.service;

/**
 *
 * @author DELL
 */
public class ProyectoService {
    public String estado(int costo, int venta){
        return (venta> costo*1.5) ?"Caro":"Barato";
    }
}
