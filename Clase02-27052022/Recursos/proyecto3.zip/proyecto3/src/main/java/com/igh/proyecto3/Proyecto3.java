
package com.igh.proyecto3;
import com.igh.proyecto3.view.ImporteView;

/**
 *
 * @author stoop
 */
public class Proyecto3 {

    public static void main(String[] args) {
        ImporteView.main(args);
    }
}
