
package com.igh.proyecto3.service;

/**
 * @author A.A.Abad
 */
public class ImporteService {
    
    public double ImporteFinal(int cantidad, double costo) {
	double porcDcto = 0.0, PF;
        porcDcto = (cantidad >= 12 && cantidad < 24) ? 0.05 : porcDcto;
        porcDcto = (cantidad >= 24 && cantidad < 36) ? 0.10 : porcDcto;
        porcDcto = (cantidad >= 36) ? 0.15 : porcDcto;
        PF = costo - costo * porcDcto;
        return PF;
    }
}
