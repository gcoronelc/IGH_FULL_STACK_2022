
package com.igh.proyecto3.pruebas;

import com.igh.proyecto3.service.ImporteService;

/**
 * @author A.A.Abad
 */
public class Prueba01 {
    
    public static void main(String[] args) {
		// Variables
		int cantidad;
                double costo, importe;
		// Datos
		cantidad = 67;
		costo = 30;
		// Proceso
		ImporteService importeService = new ImporteService();
		importe = importeService.ImporteFinal(cantidad, costo);
		// Reporte
		System.out.println(importe);
	}

}
