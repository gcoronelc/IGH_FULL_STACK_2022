
package com.igh.proyecto3.controller;

import com.igh.proyecto3.service.ImporteService;

/**
 * @author A.A.Abad
 */
public class ImporteController {
    
    private ImporteService importeService;

	public ImporteController() {
		importeService = new ImporteService();
	}
        
        public double ImporteFinal(int cantidad, double costo) {
		return importeService.ImporteFinal(cantidad, costo);
	}

}
