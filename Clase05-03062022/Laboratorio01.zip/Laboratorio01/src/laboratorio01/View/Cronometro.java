/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package laboratorio01.View;

import java.awt.Component;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JButton;
import javax.swing.JLabel;

/**
 *
 * @author aless
 */
public class Cronometro extends Thread {

    private boolean isStop;
    //private final Component[];

    private final JLabel jLabel;
    private final JLabel jlblResultado;
    private final JButton btnCalcular;

    private final JButton btnVerificar;
    private final JButton btnNuevo;

    public Cronometro(Component component[]) {

        this.jLabel = (JLabel) component[0];
        this.jlblResultado = (JLabel) component[1];

        this.btnCalcular = (JButton) component[2];
        this.btnVerificar = (JButton) component[3];
        this.btnNuevo = (JButton) component[4];
        
    }

    @Override
    public void run() {
        int contador = 30;
        this.isStop = false;
        while (contador >= 0 && !this.isStop) {

            jLabel.setText(contador + "");
            contador = contador - 1;
            dormir();
        }
        btnCalcular.setEnabled(false);
        if (contador <= 0) {
            jlblResultado.setText("Tiempo Expirado");
            btnVerificar.setEnabled(false);
            btnNuevo.setEnabled(true);

        } else {
            jlblResultado.setText("");
        }

    }

    private void dormir() {
        try {
            sleep(1000);
        } catch (InterruptedException ex) {
            Logger.getLogger(Cronometro.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void stopThead() {
        this.isStop = true;
    }

}
