
package laboratorio01.Prueba;

import laboratorio01.Model.Laboratorio01Model;
import laboratorio01.Service.GenerarNumeros;
import laboratorio01.Service.Laboratorio01Service;

/**
 *
 * @author aless
 */
public class Prueba01 {

    public static void main(String[] args) {

       
        Laboratorio01Model model = new Laboratorio01Model();
        GenerarNumeros generarNumeros = new GenerarNumeros();
        
        model.setBase(generarNumeros.GenerarNumeros());
        model.setAltura(generarNumeros.GenerarNumeros());
        
        
         Laboratorio01Service servicio = new Laboratorio01Service(model);
        System.out.println("LA ALTURA ES: " + servicio.CalcularArea());
  
        
    }

}
