/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package laboratorio01.Service;

import laboratorio01.Model.Laboratorio01Model;



/**
 *
 * @author aless
 */
public class Laboratorio01Service {

    private final Laboratorio01Model model;

    public Laboratorio01Service(Laboratorio01Model model) {
        this.model = model;
    }

    public double CalcularArea() {
        double area;
        int altura = model.getAltura();
        int base = model.getBase();
        area = (base * altura) ;
        area = area/2;

        return area;
    }

    public String Verficiar() {

        double AreaCalculada = CalcularArea();
        double AreaUser = model.getResultadoUser();
        System.out.println("Area1:"+AreaCalculada);
        System.out.println("Area2:"+AreaUser);
        String Resultado = (AreaUser == AreaCalculada) ? "Aprobadao" : "Desaprobado";

        return Resultado;
    }

}
