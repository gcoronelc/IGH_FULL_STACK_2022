/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package laboratorio01.Service;

import java.util.Random;
import laboratorio01.Model.Laboratorio01ModelParametros;

/**
 *
 * @author aless
 */
public class GenerarNumeros {
    
        public int GenerarNumeros() {
        
        Laboratorio01ModelParametros parametros= new Laboratorio01ModelParametros();
        
        Random random = new Random();

        int value = random.nextInt(parametros.getMaximo() + parametros.getMinimo()) + parametros.getMinimo();
        System.out.println("alear: " +value);  
        return value;
    }
        
}


