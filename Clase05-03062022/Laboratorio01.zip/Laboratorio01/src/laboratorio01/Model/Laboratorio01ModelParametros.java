/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package laboratorio01.Model;

/**
 *
 * @author aless
 */
public class Laboratorio01ModelParametros {

    private final int maximo;
    private final int minimo;


    public Laboratorio01ModelParametros() {
        this.maximo = 100;
        this.minimo = 1;
    }

    public int getMaximo() {
        return maximo;
    }

    public int getMinimo() {
        return minimo;
    }
    
    
}
