/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package laboratorio01.Model;

/**
 *
 * @author aless
 */
public class Laboratorio01Model {

    private int base;
    private int altura;
    private Double resultadoUser;

 

    public int getBase() {
        return base;
    }

    public void setBase(int base) {
        this.base = base;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public Double getResultadoUser() {
        return resultadoUser;
    }

    public void setResultadoUser(Double resultadoUser) {
        this.resultadoUser = resultadoUser;
    }

}
