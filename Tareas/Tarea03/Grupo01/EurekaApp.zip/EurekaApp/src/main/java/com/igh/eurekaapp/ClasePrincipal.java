package com.igh.eurekaapp;

import RegistroLog.LogRegistro;
import com.igh.eurekaapp.controller.LogonController;
import com.igh.eurekaapp.service.LogonService;
import com.igh.eurekaapp.view.LogonView;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Handler; 
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * @author Eric Gustavo Coronel Castillo
 * @blog www.desarrollasoftware.com
 * @email gcoronelc@gmail.com
 * @youtube www.youtube.com/DesarrollaSoftware
 * @facebook www.facebook.com/groups/desarrollasoftware
 * @cursos gcoronelc.github.io
 */
public class ClasePrincipal {

  

    public static void main(String[] args) {
        LogonView.main(args);
        
            LogRegistro logregistro = new LogRegistro();
            
                 logregistro.logRegistro();
       
    }
    

  

}
