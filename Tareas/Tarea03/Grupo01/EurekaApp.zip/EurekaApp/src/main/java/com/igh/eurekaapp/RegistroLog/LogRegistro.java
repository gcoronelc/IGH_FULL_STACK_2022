/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package RegistroLog;

import com.igh.eurekaapp.ClasePrincipal;
import com.igh.eurekaapp.controller.LogonController;
import com.igh.eurekaapp.service.LogonService;
import com.igh.eurekaapp.view.LogonView;
import static com.sun.xml.internal.ws.spi.db.BindingContextFactory.LOGGER;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import static java.lang.Thread.State.NEW;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 *
 * @author aless
 */
public class LogRegistro {
    
    
      private final static Logger LOGGER_RAIZ = Logger.getLogger("com.igh.eurekaapp");
      
      // El log para ESTA clase en particular
    private final static Logger LOGGER = Logger.getLogger("com.igh.eurekaapp.RegistroLog");
  
    public void logRegistro(){
         try {

            // Los handler (manejadores) indican a donde mandar la salida ya sea consola o archivo
            // En este caso ConsoleHandler envia los logs a la consola
            Handler consoleHandler = new ConsoleHandler();

            // Con el manejador de archivo, indicamos el archivo donde se mandaran los logs
            // El segundo argumento controla si se sobre escribe el archivo o se agregan los logs al final
            // Para sobre escribir pase un true para agregar al final, false para sobre escribir
            // todo el archivo.
            Handler fileHandler = new FileHandler("./Registro.log", true);

            // El formateador indica como presentar los datos, en este caso usaremos el formaro sencillo
            // el cual es mas facil de leer, si no usamos esto el log estara en formato xml por defecto.
            SimpleFormatter simpleFormatter = new SimpleFormatter();

            // Se especifica que formateador usara el manejador (handler) de archivo
            fileHandler.setFormatter(simpleFormatter);

            // Asignamos los handles previamente declarados al log *raiz* esto es muy importante ya que
            // permitira que los logs de todas y cada una de las clases del programa que esten en ese paquete
            // o sus subpaquetes se almacenen en el archivo y aparescan en consola
            
            LOGGER_RAIZ.addHandler(consoleHandler); 
            LOGGER_RAIZ.addHandler(fileHandler);

           
            
            consoleHandler.setLevel(Level.ALL);
            fileHandler.setLevel(Level.ALL);

            
        } catch (IOException ex) {
             LOGGER.log(Level.SEVERE,LogRegistro.getStackTrace(ex));
        } catch (SecurityException ex) {
             LOGGER.log(Level.SEVERE,LogRegistro.getStackTrace(ex));
        }
    }
    
        private static String getStackTrace(Exception e) {
        StringWriter sWriter = new StringWriter();
        PrintWriter pWriter = new PrintWriter(sWriter);
        e.printStackTrace(pWriter);
        return sWriter.toString();
        
    }

    
}
