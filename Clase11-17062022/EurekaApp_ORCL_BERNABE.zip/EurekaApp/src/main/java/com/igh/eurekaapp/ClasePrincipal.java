package com.igh.eurekaapp;

import com.igh.eurekaapp.view.LogonView;

/**
 * @author Eric Gustavo Coronel Castillo
 * @blog www.desarrollasoftware.com
 * @email gcoronelc@gmail.com
 * @youtube www.youtube.com/DesarrollaSoftware
 * @facebook www.facebook.com/groups/desarrollasoftware
 * @cursos gcoronelc.github.io
 */
public class ClasePrincipal {

	public static void main(String[] args) {
		LogonView.main(args);
	}
}
