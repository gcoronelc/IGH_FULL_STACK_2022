/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.igh.eurekaapp.controller;

import com.igh.eurekaapp.model.ClienteModel;
import com.igh.eurekaapp.service.CrudClienteService;
import java.util.List;

/**
 *
 * @author DELL
 */
public class ClienteController {
    private CrudClienteService servicio;

    public ClienteController() {
        this.servicio=new CrudClienteService();
    }
    public List<ClienteModel> cargarTodo(){
        return servicio.readAll();
    }
    public ClienteModel buscarCodigo(String codigo){
        return servicio.read(codigo);
    }
    public List<ClienteModel> buscarCampos(ClienteModel cliente){
        return servicio.readAll(cliente);
    }
    public void insertarCliente(ClienteModel cliente){
        servicio.insert(cliente);
    }
    public void modificarCliente(ClienteModel cliente){
        servicio.update(cliente);
    }
    public void delete(String codigo){
        servicio.delete(codigo);
    }
    
}
